var zy_origFbAsyncInit = window.fbAsyncInit;
window.fbAsyncInit = function () {
	var
		initialFunc = window.fbAsyncInit,
		startTime = new Date() / 1000
	;
	if (zy_origFbAsyncInit !== undefined) {
		// Call the original if it existed
		window.setTimeout(zy_origFbAsyncInit, 0);
	}
	function checkForNewFbAsyncInit() {
		// See if we have a new async init function that is not the one that we set
		if (window.fbAsyncInit && !window.fbAsyncInit.hasRun && window.fbAsyncInit !== initialFunc) {
			window.fbAsyncInit.hasRun = true;
			fbAsyncInit();
			initialFunc = fbAsyncInit;
		}
		// Still waiting or a new one so try again in 10ms as long as we haven't been trying for more than 10s
		if ((new Date() / 1000) - startTime < 10) {
			window.setTimeout(checkForNewFbAsyncInit, 10);
		}
	}
	checkForNewFbAsyncInit();
}
if (zy_origFbAsyncInit && zy_origFbAsyncInit.hasRun) {
	// all.js has already run AND called a fbAsyncInit() function
	window.fbAsyncInit();
}